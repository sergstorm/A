import Barier.Bars;
import Barier.River;
import Barier.Wall;
import Compet.Cat;
import Compet.Competetor;
import Compet.Human;

public class Programm {
    public static void main(String[] args) {
        System.out.println("Start");

        Competetor competetor[] = {new Human(12,13),new Cat(23,55)};  // Создаем команду
        Bars bars[] = {new Wall(23),new River(345)};// Создаем полосу препятствий

        bars[0].doit(); // Просим команду пройти полосу
        competetor[0].showresults(); // Показываем результаты


    }
}
