package Barier;

public class River implements Bars {
    private int length;

    public River(int length) {
       // super(55);
        this.length = length;
    }

    @Override
    public void doit() {

    }
}
