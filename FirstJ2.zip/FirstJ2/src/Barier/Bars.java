package Barier;

public interface Bars {
       public void doit();
}
