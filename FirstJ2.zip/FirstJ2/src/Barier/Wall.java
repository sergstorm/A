package Barier;

public class Wall implements Bars
{
  private int heght;

    public Wall(int heght) {
       // super(45);
        this.heght = heght;
    }

    @Override
    public void doit() {

    }
}