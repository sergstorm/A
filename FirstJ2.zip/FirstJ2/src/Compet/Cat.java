package Compet;

public class Cat implements Competetor{
    private int runleght;
    private int swimlenght;

    public Cat(int runleght, int swimlenght) {
        this.runleght = runleght;
        this.swimlenght = swimlenght;
    }

    @Override
    public void run(int p) {
        System.out.println("Cat run");
    }

    @Override
    public void swim(int p) {
        System.out.println("Cat swim");
    }

    @Override
    public void showresults() {

    }
}
