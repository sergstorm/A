package Compet;

public interface Competetor {

    public void run(int p);
    public void swim(int p);
    public void showresults();
}
