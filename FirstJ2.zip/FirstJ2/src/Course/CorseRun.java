package Course;

import Barier.Bars;
import Compet.Competetor;

public class CorseRun implements Bars ,Competetor{


    @Override
    public void run(int p) {

    }

    @Override
    public void swim(int p) {

    }

    @Override
    public void showresults() {

    }

    @Override
    public void doit() {

    }
}
