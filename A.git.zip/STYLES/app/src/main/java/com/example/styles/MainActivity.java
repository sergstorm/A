package com.example.styles;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button,counterbutton;
    TextView textView,textViewCount;
    EditText editText;
    private int counter = 0 ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button.setText(getString(R.string.click));
                textView.setText(getString(R.string.butto_clicked+counter));

                Context context = MainActivity.this;
                Class destinationactivity =ChildActivity.class;
                Intent childActivityIntent = new Intent(context,destinationactivity);
                childActivityIntent.putExtra(Intent.EXTRA_TEXT,editText.getText().toString());
                startActivity(childActivityIntent);
            }
        });

        counterbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter++;
                textViewCount.setText(((Integer)counter).toString());
            }
        });

    }
    @Override
    protected void onSaveInstanceState(Bundle saveInstanceState){
        super.onSaveInstanceState(saveInstanceState);
        Toast.makeText(getApplicationContext(), "onSaveInstanceState()", Toast.LENGTH_SHORT).show();
        saveInstanceState.putInt("Counter", counter);               // Сохраняем счетчик
    }
    @Override
    protected void onRestoreInstanceState(Bundle saveInstanceState){
        super.onRestoreInstanceState(saveInstanceState);
        Toast.makeText(getApplicationContext(), "Повторный запуск!! - onRestoreInstanceState()", Toast.LENGTH_SHORT).show();
        counter = saveInstanceState.getInt("Counter");              // Восстанавливаем счетчик
        textViewCount.setText(((Integer)counter).toString());         // Выводим счетчик в поле
    }



    private void initialize() {
        button = findViewById(R.id.button);
        textView = findViewById(R.id.textView);
        editText  = findViewById(R.id.editText);
        counterbutton = findViewById(R.id.button3);
        textViewCount = findViewById(R.id.textView3);
    }
}
