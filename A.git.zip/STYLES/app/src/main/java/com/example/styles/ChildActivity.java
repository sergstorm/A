package com.example.styles;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ChildActivity extends AppCompatActivity {
  Button button2;
    TextView textView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child);


        button2 = findViewById(R.id.button2);
        textView2 = findViewById(R.id.textView2);

        Intent intentThatStartedThisActivity = getIntent();
        //String textfromfirstactivity = intentThatStartedThisActivity.getStringExtra("s");
        if (intentThatStartedThisActivity.hasExtra(Intent.EXTRA_TEXT))
        {
            String textEntered = intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_TEXT);
            textView2.setText(textEntered);
        }
        textView2.setText(intentThatStartedThisActivity.getDataString());
        button2.setText(intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_TEXT));
    }
}
