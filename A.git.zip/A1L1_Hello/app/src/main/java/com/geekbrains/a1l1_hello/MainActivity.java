package com.geekbrains.a1l1_hello;

import android.graphics.Color;
import android.icu.util.Calendar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView greeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        greeting = findViewById(R.id.textView);
        String text = new GreetingsBuilder().getGreetings(getApplicationContext());
        greeting.setText(text);
        /*textView = findViewById(R.id.textView);
        textView.setText(getString(R.string.hello));
        int color = ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary);
        textView.setTextColor(color);*/
    }
}
